package net.hb.crud;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class BoardService {
	public void boardInsert() {
		
	};//end
	public List boardSelect() {
		List list = null;
		return list;
	};//end
	
	public void boardDetail(int data) {
		
	};//end
	
	public int boardCount() {
		return 340;
	};//end
	
	public void boardDelete(int data) {
		
	};//end
	
	public void boardEdit() {
		
	};//end
}
